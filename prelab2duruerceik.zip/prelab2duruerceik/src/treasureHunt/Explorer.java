package treasureHunt;

public class Explorer {
	private String name;
	private int explorerID;
	
	public Explorer(String name, int explorerID) {
		this.name=name;
		this.explorerID=explorerID;
		
		
	}
	public String getName() {
		return name;
	}
	public int getExplorerID() {
		return explorerID;
	}

}
